# Extensions

This directory is used for additional script and style files. You have to add
them manualy to the `resources` section in `_h5ai/private/conf/options.json`.
