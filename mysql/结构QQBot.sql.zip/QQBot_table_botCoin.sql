
-- --------------------------------------------------------

--
-- 表的结构 `botCoin`
--

CREATE TABLE `botCoin` (
  `id` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `value` bigint(20) NOT NULL,
  `toushi` int(11) NOT NULL,
  `cid` varchar(255) NOT NULL,
  `shiye` int(11) NOT NULL,
  `taohua` int(11) NOT NULL,
  `cai` int(11) NOT NULL,
  `zong` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
