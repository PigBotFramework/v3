
-- --------------------------------------------------------

--
-- 表的结构 `botSettings`
--

CREATE TABLE `botSettings` (
  `id` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `power` int(11) NOT NULL DEFAULT '1',
  `replyPercent` int(11) NOT NULL DEFAULT '100',
  `autoAcceptGroup` int(11) NOT NULL DEFAULT '1',
  `recallFlag` int(11) NOT NULL DEFAULT '1',
  `admin` int(11) NOT NULL DEFAULT '1',
  `decrease` int(11) NOT NULL DEFAULT '1',
  `increase` int(11) NOT NULL DEFAULT '1',
  `AntiswipeScreen` int(11) NOT NULL DEFAULT '10',
  `increase_notice` varchar(255) NOT NULL DEFAULT '欢迎入群！（请管理自定义入群欢迎内容）',
  `weijinCheck` int(11) NOT NULL DEFAULT '0',
  `keywordReply` int(11) NOT NULL DEFAULT '1',
  `bannedCount` int(11) NOT NULL DEFAULT '0',
  `MCSMApi` varchar(255) NOT NULL,
  `MCSMUuid` varchar(255) NOT NULL,
  `MCSMRemote` varchar(255) NOT NULL,
  `MCSMKey` varchar(255) NOT NULL,
  `messageSync` int(11) NOT NULL DEFAULT '0',
  `dui` int(11) NOT NULL,
  `delete_es` int(11) NOT NULL DEFAULT '0',
  `increase_verify` int(11) NOT NULL DEFAULT '0',
  `translateLang` varchar(255) NOT NULL DEFAULT 'zh-cn',
  `MC_random` int(11) NOT NULL DEFAULT '0',
  `connectQQ` bigint(20) NOT NULL,
  `decrease_notice_kick` varchar(255) NOT NULL DEFAULT '成员{user}被{operator}踢出了本群',
  `decrease_notice_leave` varchar(255) NOT NULL DEFAULT '成员{user}主动离开了本群',
  `only_for_uid` varchar(255) NOT NULL DEFAULT '',
  `v_command` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
