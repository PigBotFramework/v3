
-- --------------------------------------------------------

--
-- 表的结构 `botPlugins`
--

CREATE TABLE `botPlugins` (
  `id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
