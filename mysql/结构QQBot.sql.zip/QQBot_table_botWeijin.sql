
-- --------------------------------------------------------

--
-- 表的结构 `botWeijin`
--

CREATE TABLE `botWeijin` (
  `id` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `uuid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
