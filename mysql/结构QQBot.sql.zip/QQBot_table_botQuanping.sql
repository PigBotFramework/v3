
-- --------------------------------------------------------

--
-- 表的结构 `botQuanping`
--

CREATE TABLE `botQuanping` (
  `id` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
