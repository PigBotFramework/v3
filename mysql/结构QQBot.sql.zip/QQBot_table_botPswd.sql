
-- --------------------------------------------------------

--
-- 表的结构 `botPswd`
--

CREATE TABLE `botPswd` (
  `id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
