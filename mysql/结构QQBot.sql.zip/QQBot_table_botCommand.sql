
-- --------------------------------------------------------

--
-- 表的结构 `botCommand`
--

CREATE TABLE `botCommand` (
  `id` int(11) NOT NULL,
  `content` varchar(255) NOT NULL COMMENT '指令内容',
  `usage` varchar(255) NOT NULL COMMENT '指令用法',
  `promise` varchar(255) NOT NULL COMMENT '权限',
  `func` varchar(255) NOT NULL COMMENT '执行语句',
  `eval` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL COMMENT '解释',
  `mode` varchar(255) NOT NULL COMMENT '归类',
  `isHide` int(11) NOT NULL COMMENT '0为显示，1为隐藏，2为简略'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
