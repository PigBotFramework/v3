
-- --------------------------------------------------------

--
-- 表的结构 `botBotconfig`
--

CREATE TABLE `botBotconfig` (
  `id` int(11) NOT NULL,
  `httpurl` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `secret` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `bannedCount` int(11) NOT NULL,
  `defaultCoin` int(11) NOT NULL,
  `coinPercent` int(11) NOT NULL,
  `lowRandomCoin` int(11) NOT NULL,
  `highRandomCoin` int(11) NOT NULL,
  `owner` bigint(20) NOT NULL,
  `second_owner` bigint(20) NOT NULL,
  `yiyan` int(11) NOT NULL,
  `duiapi` varchar(255) NOT NULL,
  `musicApi` varchar(255) NOT NULL,
  `musicApiLimit` int(11) NOT NULL,
  `headImageApi` varchar(255) NOT NULL,
  `myselfqn` bigint(20) NOT NULL,
  `autoAcceptGroup` int(11) NOT NULL,
  `autoAcceptFriend` int(11) NOT NULL,
  `bilidownPart` int(11) NOT NULL,
  `bilidownType` int(11) NOT NULL,
  `bilidownCodecs` int(11) NOT NULL,
  `bilidownCookie` varchar(255) NOT NULL,
  `bilidownByte` int(11) NOT NULL,
  `CrashReport` int(11) NOT NULL,
  `reportAt` int(11) NOT NULL,
  `reportPrivate` int(11) NOT NULL,
  `defaultPower` int(11) NOT NULL,
  `host` varchar(255) NOT NULL,
  `port` int(11) NOT NULL,
  `only_for_uid` bigint(20) NOT NULL DEFAULT '0',
  `chuo` varchar(1000) NOT NULL DEFAULT '不要戳我啦 我爱你，别戳了！'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
