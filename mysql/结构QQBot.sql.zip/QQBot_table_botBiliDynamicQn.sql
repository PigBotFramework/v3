
-- --------------------------------------------------------

--
-- 表的结构 `botBiliDynamicQn`
--

CREATE TABLE `botBiliDynamicQn` (
  `id` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
