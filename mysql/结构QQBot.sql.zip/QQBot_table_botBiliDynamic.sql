
-- --------------------------------------------------------

--
-- 表的结构 `botBiliDynamic`
--

CREATE TABLE `botBiliDynamic` (
  `id` int(11) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `offset` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
