
-- --------------------------------------------------------

--
-- 表的结构 `botWebsiteFeedback`
--

CREATE TABLE `botWebsiteFeedback` (
  `id` int(11) NOT NULL,
  `question` longtext NOT NULL,
  `answer` longtext NOT NULL,
  `time` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'question_answer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
