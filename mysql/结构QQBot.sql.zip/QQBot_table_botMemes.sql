
-- --------------------------------------------------------

--
-- 表的结构 `botMemes`
--

CREATE TABLE `botMemes` (
  `id` int(11) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
