
-- --------------------------------------------------------

--
-- 表的结构 `botLangrensha`
--

CREATE TABLE `botLangrensha` (
  `id` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `1` bigint(20) NOT NULL COMMENT '预言家',
  `2` bigint(20) NOT NULL COMMENT '守卫',
  `3` bigint(20) NOT NULL COMMENT '女巫',
  `4` bigint(20) NOT NULL COMMENT '猎人',
  `5` bigint(20) NOT NULL COMMENT '狼人1',
  `6` bigint(20) NOT NULL COMMENT '狼人2',
  `7` bigint(20) NOT NULL COMMENT '狼人3',
  `8` bigint(20) NOT NULL COMMENT '白狼王',
  `9` bigint(20) NOT NULL COMMENT '民1',
  `10` bigint(20) NOT NULL COMMENT '民2',
  `11` bigint(20) NOT NULL COMMENT '民3',
  `12` bigint(20) NOT NULL COMMENT '民4',
  `uuid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
