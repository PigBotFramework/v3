
-- --------------------------------------------------------

--
-- 表的结构 `botReportcon`
--

CREATE TABLE `botReportcon` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `user` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `to_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
