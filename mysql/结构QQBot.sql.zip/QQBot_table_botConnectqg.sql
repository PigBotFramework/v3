
-- --------------------------------------------------------

--
-- 表的结构 `botConnectqg`
--

CREATE TABLE `botConnectqg` (
  `id` int(11) NOT NULL,
  `uid` bigint(20) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `gid` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
