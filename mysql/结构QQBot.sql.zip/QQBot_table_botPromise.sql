
-- --------------------------------------------------------

--
-- 表的结构 `botPromise`
--

CREATE TABLE `botPromise` (
  `id` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `gid` bigint(20) NOT NULL,
  `command` varchar(255) NOT NULL,
  `promise` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
