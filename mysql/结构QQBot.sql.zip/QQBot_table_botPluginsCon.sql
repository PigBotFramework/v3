
-- --------------------------------------------------------

--
-- 表的结构 `botPluginsCon`
--

CREATE TABLE `botPluginsCon` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `user` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `for` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
