
--
-- 转储表的索引
--

--
-- 表的索引 `botBiliDynamic`
--
ALTER TABLE `botBiliDynamic`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botBiliDynamicQn`
--
ALTER TABLE `botBiliDynamicQn`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botBotconfig`
--
ALTER TABLE `botBotconfig`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botBugreport`
--
ALTER TABLE `botBugreport`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botCoin`
--
ALTER TABLE `botCoin`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botCommand`
--
ALTER TABLE `botCommand`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botConfiglist`
--
ALTER TABLE `botConfiglist`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botConnectqg`
--
ALTER TABLE `botConnectqg`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botKeyword`
--
ALTER TABLE `botKeyword`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botLangrensha`
--
ALTER TABLE `botLangrensha`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botMC`
--
ALTER TABLE `botMC`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botMemes`
--
ALTER TABLE `botMemes`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botNotice`
--
ALTER TABLE `botNotice`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botPlugins`
--
ALTER TABLE `botPlugins`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botPluginsCon`
--
ALTER TABLE `botPluginsCon`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botPromise`
--
ALTER TABLE `botPromise`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botPswd`
--
ALTER TABLE `botPswd`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botQuanping`
--
ALTER TABLE `botQuanping`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botReplace`
--
ALTER TABLE `botReplace`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botReportcon`
--
ALTER TABLE `botReportcon`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botSettingName`
--
ALTER TABLE `botSettingName`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botSettings`
--
ALTER TABLE `botSettings`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botWebsiteConfig`
--
ALTER TABLE `botWebsiteConfig`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botWebsiteFeedback`
--
ALTER TABLE `botWebsiteFeedback`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botWeijin`
--
ALTER TABLE `botWeijin`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `botWhitelist`
--
ALTER TABLE `botWhitelist`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `botBiliDynamic`
--
ALTER TABLE `botBiliDynamic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botBiliDynamicQn`
--
ALTER TABLE `botBiliDynamicQn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botBotconfig`
--
ALTER TABLE `botBotconfig`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botBugreport`
--
ALTER TABLE `botBugreport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botCoin`
--
ALTER TABLE `botCoin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botCommand`
--
ALTER TABLE `botCommand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botConfiglist`
--
ALTER TABLE `botConfiglist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botConnectqg`
--
ALTER TABLE `botConnectqg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botKeyword`
--
ALTER TABLE `botKeyword`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botLangrensha`
--
ALTER TABLE `botLangrensha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botMC`
--
ALTER TABLE `botMC`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botMemes`
--
ALTER TABLE `botMemes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botNotice`
--
ALTER TABLE `botNotice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botPlugins`
--
ALTER TABLE `botPlugins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botPluginsCon`
--
ALTER TABLE `botPluginsCon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botPromise`
--
ALTER TABLE `botPromise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botPswd`
--
ALTER TABLE `botPswd`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botQuanping`
--
ALTER TABLE `botQuanping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botReplace`
--
ALTER TABLE `botReplace`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botReportcon`
--
ALTER TABLE `botReportcon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botSettingName`
--
ALTER TABLE `botSettingName`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botSettings`
--
ALTER TABLE `botSettings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botWebsiteConfig`
--
ALTER TABLE `botWebsiteConfig`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botWebsiteFeedback`
--
ALTER TABLE `botWebsiteFeedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botWeijin`
--
ALTER TABLE `botWeijin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `botWhitelist`
--
ALTER TABLE `botWhitelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
