
-- --------------------------------------------------------

--
-- 表的结构 `botMC`
--

CREATE TABLE `botMC` (
  `id` int(11) NOT NULL,
  `qn` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `backpack` longtext NOT NULL,
  `life` int(11) NOT NULL,
  `hungry` int(11) NOT NULL,
  `achievement` longtext NOT NULL,
  `xp` int(11) NOT NULL,
  `doing` varchar(255) NOT NULL,
  `doingutill` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
