
-- --------------------------------------------------------

--
-- 表的结构 `botReplace`
--

CREATE TABLE `botReplace` (
  `id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `explain` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
