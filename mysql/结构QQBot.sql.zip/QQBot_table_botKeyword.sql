
-- --------------------------------------------------------

--
-- 表的结构 `botKeyword`
--

CREATE TABLE `botKeyword` (
  `id` int(11) NOT NULL,
  `key` longtext NOT NULL,
  `value` longtext NOT NULL,
  `time` int(11) NOT NULL,
  `state` int(11) NOT NULL,
  `uid` bigint(11) NOT NULL,
  `coin` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `qn` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
