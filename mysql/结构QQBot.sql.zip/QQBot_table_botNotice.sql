
-- --------------------------------------------------------

--
-- 表的结构 `botNotice`
--

CREATE TABLE `botNotice` (
  `id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `time` int(11) NOT NULL,
  `uuid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
