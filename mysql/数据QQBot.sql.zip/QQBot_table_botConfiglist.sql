
--
-- 转存表中的数据 `botConfiglist`
--

INSERT INTO `botConfiglist` (`id`, `key`, `type`, `description`, `name`, `sample`) VALUES
(1, 'secret', 'varchar', '机器人通信密钥，请与gocq配置中的server->post->secret字段保持一致', '机器人通信密钥', ''),
(2, 'name', 'varchar', '机器人叫什么？', '机器人昵称', ''),
(3, 'bannedCount', 'int', '最多对机器人行使几次神权，多了自动退群', '神权次数', '3'),
(4, 'defaultCoin', 'int', '注册时默认给的好感度', '默认好感度', '50'),
(5, 'coinPercent', 'int', '随机加好感度概率，设定值分之一', '好感度概率', '5'),
(6, 'lowRandomCoin', 'int', '随机加好感度的最低值', '好感度最低值', '3'),
(7, 'highRandomCoin', 'int', '随机加好感度的最高值', '好感度最高值', '5'),
(8, 'owner', 'int', '主人QQ号，请您不要乱改此项，将会转移机器人！', '主人QQ号', '2417481092'),
(9, 'yiyan', 'int', '有人骂机器人怼回去的消息数', '怼消息数', '1'),
(10, 'duiapi', 'varchar', '怼人API（见 https://github.com/cndiandian/zuanbot.com）', '怼人接口', 'https://zuan.xzy.center/api.php?level=min&lang=zh_cn'),
(12, 'musicApiLimit', 'int', '搜歌每页数量', '搜歌数量', '5'),
(13, 'headImageApi', 'varchar', '获取头像接口', '头像接口', 'https://api.muxiaoguo.cn/api/QqInfo?api_key=e2bb8bb80d003369&qq={0}'),
(14, 'myselfqn', 'int', '机器人QQ号，请谨慎修改此项！', '机器人QQ号', ''),
(15, 'autoAcceptGroup', 'boolean', '自动同意邀请入群请求', '邀请请求', '1'),
(16, 'autoAcceptFriend', 'boolean', '自动同意加好友请求', '加好友请求', '1'),
(17, 'httpurl', 'varchar', 'go-cqhttp的http地址（不能是局域网IP）', 'gocq地址', '0'),
(18, 'CrashReport', 'int', '机器人控制台输出发送到的群聊', '控制台输出', '983166965'),
(19, 'second_owner', 'int', '副主人QQ号', '副主人QQ号', '2417481092'),
(20, 'reportAt', 'boolean', '有人艾特主人和副主人时机器人私聊提示', '上报艾特', '1'),
(21, 'reportPrivate', 'boolean', '有人私聊机器人时转发消息给主人和副主人并允许主人直接回复', '上报私聊消息', '1'),
(22, 'defaultPower', 'boolean', '开启后机器人加入新群默认开机，关闭则默认关机', '默认开关机', '1'),
(23, 'host', 'varchar', '机器的IP地址（不要带http头，不能是局域网IP）', 'gocq地址', ''),
(24, 'port', 'int', 'go-cqhttp的端口（记得安全组放行）', 'gocq端口', ''),
(25, 'only_for_uid', 'int', '跟班模式，让机器人只回复某个人的话，其他人说话都不搭理，如果取消该项设置请设置为0，否则为跟班主人的QQ号', '跟班模式', '0'),
(26, 'chuo', 'varchar', '戳机器人的时候回复的消息（多条用空格隔开，回复时随机选取，设置为空则不回复）', '戳回复', '不要戳我啦 我爱你，别戳了！');
