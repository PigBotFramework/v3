
--
-- 转存表中的数据 `botSettingName`
--

INSERT INTO `botSettingName` (`id`, `name`, `description`, `other`, `isHide`, `type`) VALUES
(3, '消息同步', 'messageSync', '将MC服务器与本群消息同步', 0, 'boolean'),
(4, '自动接受加群请求', 'autoAcceptGroup', '', 0, 'boolean'),
(5, '消息防撤回', 'recallFlag', '', 0, 'boolean'),
(6, '管理员变动提醒', 'admin', '', 0, 'boolean'),
(7, '出群提醒', 'decrease', '', 0, 'boolean'),
(8, '入群提醒', 'increase', '', 0, 'boolean'),
(9, '违禁词检测', 'weijinCheck', '', 0, 'boolean'),
(10, '关键词回复', 'keywordReply', '', 0, 'boolean'),
(11, '防刷屏', 'AntiswipeScreen', '用户连续发送超过设定数量时禁言', 0, ''),
(12, '入群欢迎消息', 'increase_notice', '', 0, ''),
(13, 'MCSM接口地址', 'MCSMApi', 'MCSM面板的API接口地址（如不使用MC服务器功能则留空）', 1, ''),
(14, 'MCSM实例uuid', 'MCSMUuid', 'MCSM实例的远程/本地实例标识符（如不使用MC服务器功能则留空）', 1, ''),
(15, 'MCSM实例remote_uuid', 'MCSMRemote', 'MCSM实例的守护进程标识符（如不使用MC服务器功能则留空）', 1, ''),
(16, 'MCSM用户apikey', 'MCSMKey', 'MCSM的用户的apikey（如不使用MC服务器功能则留空）', 1, ''),
(17, '自动撤回精华', 'delete_es', '将除群主设置的精华自动撤回', 0, 'boolean'),
(18, '入群验证限制时间', 'increase_verify', '入群验证限制时间，超时将被kick', 0, 'int'),
(19, '国际化', 'translateLang', '将机器人发送消息翻译为设定语言', 0, ''),
(20, 'MC游戏随机事件概率', 'MC_random', '包括回血、遇到怪物等随机事件的概率，为设定值分之一', 0, 'int'),
(21, '主动退群通知', 'decrease_notice_leave', '用户主动退群时发送的消息，{user}表示退群用户', 0, 'varchar'),
(22, '踢出群聊通知', 'decrease_notice_kick', '用户被踢出群时发送的消息，{user}表示退群用户，{operator}表示艾特操作者', 0, 'varchar'),
(23, '专属模式', 'only_for_uid', '让机器人只处理设定的人的消息，如果有多个人，请用空格间隔，如果要让机器人处理所有的消息，请留空', 0, 'varchar'),
(24, '允许的指令', 'v_command', '当开启专属模式时，群成员依然可用的指令。多个指令空格间隔', 0, 'varchar');
