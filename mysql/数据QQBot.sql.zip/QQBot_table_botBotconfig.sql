
--
-- 转存表中的数据 `botBotconfig`
--

INSERT INTO `botBotconfig` (`id`, `httpurl`, `uuid`, `secret`, `name`, `bannedCount`, `defaultCoin`, `coinPercent`, `lowRandomCoin`, `highRandomCoin`, `owner`, `second_owner`, `yiyan`, `duiapi`, `musicApi`, `musicApiLimit`, `headImageApi`, `myselfqn`, `autoAcceptGroup`, `autoAcceptFriend`, `bilidownPart`, `bilidownType`, `bilidownCodecs`, `bilidownCookie`, `bilidownByte`, `CrashReport`, `reportAt`, `reportPrivate`, `defaultPower`, `host`, `port`, `only_for_uid`, `chuo`) VALUES
(0, 'gocq地址', '123456789', '通信密钥', '小猪比', 3, 50, 5, 3, 5, 2417481092, 1369787140, 1, 'https://zuan.xzy.center/api.php?level=min&lang=zh_cn', '', 5, 'https://api.muxiaoguo.cn/api/QqInfo?api_key=e2bb8bb80d003369&qq={0}', 3558267090, 1, 1, 0, 0, 0, '', 0, 983166965, 0, 0, 1, 'gocq主机', 5700, 0, '不要戳我啦 我爱你，别戳了！ 猪比怕疼，嘤嘤嘤');
