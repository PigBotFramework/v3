
--
-- 转存表中的数据 `botWebsiteConfig`
--

INSERT INTO `botWebsiteConfig` (`id`, `key`, `value`, `time`) VALUES
(1, 'portCount', '18', 0),
(2, 'pswd', 'xxxx', 0);
