
--
-- 转存表中的数据 `botReplace`
--

INSERT INTO `botReplace` (`id`, `key`, `value`, `explain`) VALUES
(1, '%atMyself%', '\'[CQ:at,qq=\'+str(self.botSettings.get(\'myselfqn\'))+\']\'', '艾特机器人自己'),
(2, '%atUser%', '\'[CQ:at,qq=\'+str(self.se.get(\'user_id\'))+\']\'', '艾特触发回复的消息发送者'),
(3, '%pokeMyself%', '\'[CQ:poke,qq=\'+str(self.botSettings.get(\'myselfqn\'))+\']\'', '戳机器人自己'),
(4, '%pokeUser%', '\'[CQ:poke,qq=\'+str(self.se.get(\'user_id\'))+\']\'', '戳触发回复的消息发送者'),
(5, '%reply%', '\'[CQ:reply,id=\'+str(self.se.get(\'message_id\'))+\']\'', '回复触发的消息'),
(6, '%userSex%', 'self.se.get(\'sender\').get(\'sex\')', '触发消息者的性别'),
(7, '%userTitle%', 'self.se.get(\'sender\').get(\'title\')', '触发消息者的专属头衔'),
(8, '%userLevel%', 'self.se.get(\'sender\').get(\'level\')', '触发消息者的群等级'),
(9, '%userArea%', 'self.se.get(\'sender\').get(\'area\')', '触发消息者的地区'),
(10, '%userAge%', 'self.se.get(\'sender\').get(\'age\')', '触发消息者的年龄'),
(11, '%userNickname%', 'self.se.get(\'sender\').get(\'nickname\')', '触发消息者的昵称'),
(12, '%userId%', 'self.se.get(\'user_id\')', '触发消息者的QQ号'),
(13, '%userCoin%', 'self.userCoin', '用户的好感度'),
(16, '%botUuid%', 'self.uuid', '机器人UUID');
